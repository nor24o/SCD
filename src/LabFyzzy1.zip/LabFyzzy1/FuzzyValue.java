package LabFyzzy1;

public enum FuzzyValue {NL, NM, ZR, PM, PL;}
